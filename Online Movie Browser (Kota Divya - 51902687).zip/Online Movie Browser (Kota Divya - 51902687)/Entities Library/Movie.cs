﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//using System.Web.Mvc;


namespace OMBEntitiesLib
{
    public class Movie
    {
        public int MovieId { get; set; }
        public string MovieName { get; set; }
        public string Pic { get; set; }
        public string Director { get; set; }
        public string plot { get; set; }
        public int Year { get; set; }
        public List<Genre> Genres { get; set; }
        public List<Actor> Actors { get; set; }
        public string BoxOffice { get; set; }
        public DateTime ReleasedDate { get; set; }
    }
}
