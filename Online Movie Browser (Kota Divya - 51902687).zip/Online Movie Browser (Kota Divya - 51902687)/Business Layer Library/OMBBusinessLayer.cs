﻿using OMBEntitiesLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OMBDataAccessLib;
using System.Web.Mvc;

namespace OMBBusinessLayerLib
{
    public class OMBBusinessLayer : IOMBBusinessLayer
    {

        /// <summary>
        /// This method is used to add movie to database
        /// </summary>
        /// <param name="movie"></param> It is used to pass movie detail inorder to add into database 
        public void AddMovieDetails(Movie movie)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            dal.AddMovieDetails(movie);
        }


        /// <summary>
        /// This method is used to delete a movie based on movie id in the database via data access layer
        /// </summary>
        /// <param name="movieId"></param> It is used to pass the movie id whose movie record is to be deleted in database via data access layer
        public void DeleteMovieByMovieId(int movieId)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            dal.DeleteMovieByMovieId(movieId);
        }


        /// <summary>
        /// This method is used to retrieve all the movies from database via data access layer
        /// </summary>
        /// <returns></returns>
        public List<Movie> GetAllMovies()
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            List<Movie> movieLst = dal.GetAllMovies();

            return movieLst;
        }


        /// <summary>
        /// This method is used to retrieve movie detail based on movie id from data access layer
        /// </summary>
        /// <param name="movieId"></param> It is used to pass movie id whose movie record is to be 
        /// retrieved from database via data access layer
        /// <returns></returns>
        public Movie GetMovieDetailsByMovieId(int movieId)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            Movie movie = dal.GetMovieDetailsByMovieId(movieId);

            return movie;
        }


        /// <summary>
        /// This method is used to retrieve the list of movies based on movie name from database 
        /// via data access layer
        /// </summary>
        /// <param name="movieName"></param> It is used to pass movie name inorder to get record which
        /// contains list of movies from data access layer
        /// <returns></returns>
        public List<Movie> GetMoviesByName(string movieName)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            List<Movie> moviesLst = dal.GetMoviesByName(movieName);

            return moviesLst;
        }


        /// <summary>
        /// This method is used to retrieve user/owner record from database via data access layer
        /// </summary>
        /// <returns></returns>
        public UserDetail GetUserDetails()
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            UserDetail user = dal.GetUserDetails();

            return user;
        }


        /// <summary>
        /// This method is used to retrieve the list of actors from database via data access layer
        /// </summary>
        /// <returns></returns>
        public List<Actor> GetAllActors()
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            var actorsLst = dal.GetAllActors();
            return actorsLst;
        }


        /// <summary>
        /// This method is used to retrieve the list of genres from database via data access layer
        /// </summary>
        /// <returns></returns>
        public List<Genre> GetAllGenres()
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            var genresLst = dal.GetAllGenres();
            return genresLst;
        }


        /// <summary>
        /// This method is used to add new admin/user credentials to database via data access layer
        /// </summary>
        /// <param name="user"></param> It is used to pass admin/user credentials to database 
        public void AddUserRegistrationDetails(UserRegistration user)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            dal.AddUserRegistrationDetails(user);
        }


        /// <summary>
        /// This method is used to retrieve user/admin record that contains user/admin name 
        /// from data access layer based on user/admin name for validation
        /// </summary>
        /// <param name="userName"></param> It is used to pass the admin/user name to retrieve a 
        /// record which contains admin name from database via data access layer
        /// <returns></returns>
        public LoginDetail GetUserNameByName(string userName)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            LoginDetail name =  dal.GetUserNameByName(userName);

            return name;
        }


        /// <summary>
        /// This method is used to retrieve user/admin record that contains user/admin password 
        /// from data access layer based on user/admin name for validation
        /// </summary>
        /// <param name="userName"></param> It is used to pass the admin/user name to retrieve a 
        /// record which contains admin password from database via data access layer
        /// <returns></returns>
        public LoginDetail GetUserPwdByName(string userName)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            LoginDetail userPwd = dal.GetUserPwdByName(userName);

            return userPwd;
        }


        /// <summary>
        /// This method is used to update a movie record based on movie id to database via data access layer
        /// </summary>
        /// <param name="movie"></param> It is used to pass updated movie record to database via
        /// data access layer
        public void UpdateMovieByMovieId(Movie movie)
        {
            OMBDataAccessLayer dal = new OMBDataAccessLayer();
            dal.UpdateMovieByMovieId(movie);
        }
    }
}
