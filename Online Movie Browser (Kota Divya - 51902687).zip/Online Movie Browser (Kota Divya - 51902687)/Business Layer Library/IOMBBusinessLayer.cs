﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using OMBEntitiesLib;

namespace OMBBusinessLayerLib
{
    interface IOMBBusinessLayer
    {
        List<Movie> GetMoviesByName(string movieName);
        Movie GetMovieDetailsByMovieId(int movieId);
        List<Movie> GetAllMovies();
        void DeleteMovieByMovieId(int movieId);
        void AddMovieDetails(Movie movie);
        List<Genre> GetAllGenres();
        List<Actor> GetAllActors();
        void UpdateMovieByMovieId(Movie movie);

        UserDetail GetUserDetails();
        void AddUserRegistrationDetails(UserRegistration user);
        LoginDetail GetUserNameByName(string userName);
        LoginDetail GetUserPwdByName(string userName);
    }
}
