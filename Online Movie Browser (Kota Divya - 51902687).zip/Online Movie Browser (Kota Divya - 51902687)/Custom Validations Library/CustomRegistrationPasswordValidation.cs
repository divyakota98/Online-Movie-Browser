﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomValidationsLib
{
    public class CustomRegistrationPasswordValidation : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null)
            {
                return false;
            }
            else
            {
                var str = value.ToString();

                if ((str.Length < 5) || (str.Length > 8))
                {
                    return false;
                }
            }

            return true;
        }
    }
}
