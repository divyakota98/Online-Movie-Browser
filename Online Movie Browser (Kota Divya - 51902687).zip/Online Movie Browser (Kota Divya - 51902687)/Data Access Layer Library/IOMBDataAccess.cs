﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OMBEntitiesLib;

namespace OMBDataAccessLib
{
    interface IOMBDataAccess
    {
        UserDetail GetUserDetails();
        List<Movie> GetMoviesByName(string movieName);
        Movie GetMovieDetailsByMovieId(int movieId);
        List<Genre> GetGenresByMovieID(int movieId);
        List<Actor> GetActorsByMovieID(int movieId);
        List<Movie> GetAllMovies();
        void AddMovieDetails(Movie movie);
        void DeleteMovieByMovieId(int movieId);
        List<Genre> GetAllGenres();
        List<Actor> GetAllActors();
        void AddGenreIdMovieId(Movie movie);
        void AddActorIdMovieId(Movie movie);
        void UpdateMovieByMovieId(Movie movie);
        void DeleteMovieGenresByMovieId(Movie movie);
        void DeleteMovieActorsByMovieId(Movie movie);

        void AddUserRegistrationDetails(UserRegistration user);
        LoginDetail GetUserNameByName(string userName);
        LoginDetail GetUserPwdByName(string userName);

    }
}
