﻿using OMBEntitiesLib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Configuration;
using OMBExceptionLib;

namespace OMBDataAccessLib
{
    public class OMBDataAccessLayer : IOMBDataAccess
    {
        SqlConnection con;
        SqlCommand cmd;


        /// <summary>
        /// This is a constructor which is used to connect with the database through ConnectionString whenever an object is created
        /// </summary>
        public OMBDataAccessLayer()
        {
            //1) Configure connection object
            con = new SqlConnection();
            con.ConnectionString = ConfigurationManager.ConnectionStrings["sqlconstr"].ConnectionString;
        }


        /// <summary>
        /// This method is used to add registration details of new admin to database
        /// </summary>
        /// <param name="user"></param> It is used to pass user credentials like UserName, password and confirmPassword to database
        public void AddUserRegistrationDetails(UserRegistration user)
        {
            try
            {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "insert into registration values(@un,@pwd,@cpwd)";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", user.UserName);
                cmd.Parameters.AddWithValue("@pwd", user.Password);
                cmd.Parameters.AddWithValue("@cpwd", user.ConfirmPwd);

                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Excute command
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch(Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) Close the connection
                con.Close();
            }
        }


        /// <summary>
        /// This method retrieve the admin record from database based on admin name
        /// </summary>
        /// <param name="userName"></param> It is used to pass the admin/user name to retrieve a record which contains admin name from database
        /// <returns></returns>
        public LoginDetail GetUserNameByName(string userName)
        {
            LoginDetail login1 = new LoginDetail();
            try
            {
                //2) Configure command
                cmd = new SqlCommand();
                cmd.CommandText = "select name from registration where name = @un";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", userName);

                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read())
                {
                    login1.Name = sdr[0].ToString();

                    sdr.Close();
                }
                else
                {
                    throw new Exception("UserName doesn't exist");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) Close the connection
                con.Close();
            }

            return login1;
        }


        /// <summary>
        /// This method retrieve the admin record from database based on admin/user name
        /// </summary>
        /// <param name="userName"></param> It is used to pass the admin/user name to retrieve a record which contains admin password from database
        /// <returns></returns>
        public LoginDetail GetUserPwdByName(string userName)
        {
            LoginDetail login2 = new LoginDetail();
            try
            {
                //2) Configure command
                cmd = new SqlCommand();
                cmd.CommandText = "select password from registration where name = @un";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@un", userName);

                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read())
                {
                    login2.Pwd = sdr[0].ToString();

                    //6) Close sdr
                    sdr.Close();
                }
                else
                {
                    throw new Exception("UserPassword code doesn't exist");
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //7) Close the connection
                con.Close();
            }

            return login2;
        }


        /// <summary>
        /// This method is used to add actorId and movieId to database and also calling AddGenreIdMovieId(Movie movie, int MovieId) method
        /// </summary>
        /// <param name="movie"></param> It is used to pass movieId and actorId into database 
        
        public void AddActorIdMovieId(Movie movie)
        {
            try
            {
                //1) Open the connection
                con.Open();
                foreach (var actor in movie.Actors)
                {
                    //2) Configure Command
                    cmd = new SqlCommand();

                    cmd.CommandText = "insert into tbl_movieactor values(@mi,@ai)";
                    cmd.Parameters.Clear();

                    cmd.Parameters.AddWithValue("@mi", movie.MovieId);
                    cmd.Parameters.AddWithValue("@ai", actor.ActorId);

                    cmd.CommandType = System.Data.CommandType.Text;

                    //3) Attach connection with command
                    cmd.Connection = con;

                    //4) Excute command
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //5) Close the connection
                con.Close();

                //Calling the method AddGenreIdMovieId(movie, movie.MovieId)
                AddGenreIdMovieId(movie);
            }
        }


        /// <summary>
        /// This method is used to add genreId and movieId to database
        /// </summary>
        /// <param name="movie"></param> It is used to pass movieId and genreId into database
       
        public void AddGenreIdMovieId(Movie movie)
        {
            try
            {
                //1) Open the connction
                con.Open();
                foreach (var genre in movie.Genres)
                {
                    //2) Configure Command
                    cmd = new SqlCommand();
                    cmd.CommandText = "insert into tbl_moviegenre values(@mi,@gi)";
                    cmd.Parameters.Clear();
                    cmd.Parameters.AddWithValue("@mi", movie.MovieId);
                    cmd.Parameters.AddWithValue("@gi", genre.GenreId);

                    cmd.CommandType = System.Data.CommandType.Text;

                    //3) Attach connection with command
                    cmd.Connection = con;

                    //4) Excute command
                    cmd.ExecuteNonQuery();
                }
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //5) Close the connection
                con.Close();
            }
        }


        /// <summary>
        /// This method is used to a add movie to database and also calling AddActorIdMovieId(movie, movie.MovieId) method
        /// </summary>
        /// <param name="movie"></param> It is used to pass a movie to database
        public void AddMovieDetails(Movie movie)
        {
            try
            {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "insert into tbl_movie values(@mi,@mn,@pic,@dir,@plot,@yr,@box,@rel)";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mi", movie.MovieId);
                cmd.Parameters.AddWithValue("@mn", movie.MovieName);
                cmd.Parameters.AddWithValue("@pic", movie.Pic);
                cmd.Parameters.AddWithValue("@dir", movie.Director);
                cmd.Parameters.AddWithValue("@plot", movie.plot);
                cmd.Parameters.AddWithValue("@yr", movie.Year);
                cmd.Parameters.AddWithValue("@box", movie.BoxOffice);
                cmd.Parameters.AddWithValue("@rel", movie.ReleasedDate);

                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Excute command
                cmd.ExecuteNonQuery();

            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) Close the connection
                con.Close();

                //Calling the method AddActorIdMovieId(movie, movie.MovieId)
                AddActorIdMovieId(movie);
            }
        }


        /// <summary>
        /// This method is used to delete a movie based on movie id
        /// </summary>
        /// <param name="movieId"></param> It is used to pass the movie id whose movie record is to be deleted in database
        public void DeleteMovieByMovieId(int movieId)
        {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "delete from tbl_movie where movieid = @id";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", movieId);

                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach command with connection
                cmd.Connection = con;

                //4) open the connection
                con.Open();

                //5) Execute the command
                int recordsAffected = cmd.ExecuteNonQuery();

                //Close the connection
                con.Close();

                if (recordsAffected == 0)
                {
                    throw new Exception("Movie details could not delete");
                }
        }


        /// <summary>
        /// This method is used to retrieve the list of actors from database based on movie id
        /// </summary>
        /// <param name="movieId"></param> It is used to pass the movie id, inorder to retrieve the record which contains the list of actors from database
        /// <returns></returns>
        public List<Actor> GetActorsByMovieID(int movieId)
        {
            List<Actor> actorsLst = new List<Actor>();

            try
            {
                //2) Configure connection
                cmd = new SqlCommand();
                cmd.CommandText = "select a.actorname from tbl_actor as a, tbl_movieactor as ma, tbl_movie as m where m.movieid=ma.movieid and a.actorid=ma.actorid and m.movieid = @mid";

                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mid", movieId);
                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Actor actor = new Actor
                    {
                        ActorName = sdr[0].ToString()
                    };
                    actorsLst.Add(actor);
                }
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) Close connection
                con.Close();
            }
            // Returns the list of actors based on movie id
            return actorsLst;
        }


        /// <summary>
        /// This method is used to retrieve the record which contains the list of actors from database
        /// </summary>
        /// <returns></returns> 
        public List<Actor> GetAllActors()
        {
            List<Actor> actorsLst = new List<Actor>();

            try
            {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "select * from tbl_actor";
                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command

                SqlDataReader sdr = cmd.ExecuteReader();

                //For query statements

                while (sdr.Read())
                {
                    Actor actor = new Actor
                    {
                        ActorId = (int)sdr[0],
                        ActorName = sdr[1].ToString(),
                    };
                    actorsLst.Add(actor);
                }
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) close the connection
                con.Close();
            }
            //return the list of actors
            return actorsLst;
        }


        /// <summary>
        /// This method is used to retrieve the record which contains the list of genres from database
        /// </summary>
        /// <returns></returns>
        public List<Genre> GetAllGenres()
        {
            List<Genre> genresLst = new List<Genre>();

            try
            {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "select * from tbl_genre";
                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command

                SqlDataReader sdr = cmd.ExecuteReader();

                //For query statements

                while (sdr.Read())
                {
                    Genre genre = new Genre
                    {
                        GenreId = (int)sdr[0],
                        GenreName = sdr[1].ToString(),
                    };
                    genresLst.Add(genre);
                }
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) close the connection
                con.Close();
            }

            //return list of genres
            return genresLst;
        }


        /// <summary>
        /// This method is used to retrieve the record which contains the list of movies from database
        /// </summary>
        /// <returns></returns>
        public List<Movie> GetAllMovies()
        {
            List<Movie> movieslst = new List<Movie>();

            try
            {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "select movieid,moviename,picture,year from tbl_movie";
                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command

                SqlDataReader sdr = cmd.ExecuteReader();

                //For query statements

                while (sdr.Read())
                {
                    Movie movie = new Movie
                    {
                        MovieId = (int)sdr[0],
                        MovieName = sdr[1].ToString(),
                        Pic = sdr[2].ToString(),
                        Year = (int)sdr[3],
                    };
                    movieslst.Add(movie);
                }
                //Close the dataReader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) close the connection
                con.Close();
            }

            //returns list of movies
            return movieslst;
        }


        /// <summary>
        /// This method is used to retrieve the record which contains the list of genres from database based on movie id
        /// </summary>
        /// <param name="movieId"></param> It is used to pass the movie id, inorder to retrieve the record which contains the list of actors from database
        /// <returns></returns>
        public List<Genre> GetGenresByMovieID(int movieId)
        {
            List<Genre> genresLst = new List<Genre>();

            try
            {
                cmd = new SqlCommand();
                cmd.CommandText = "select g.genrename from tbl_genre as g, tbl_moviegenre as mg, tbl_movie as m where m.movieid=mg.movieid and g.genreid=mg.genreid and m.movieid = @mid";

                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@mid", movieId);
                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Genre genre = new Genre
                    {
                        GenreName = sdr[0].ToString()
                    };
                    genresLst.Add(genre);
                }
                //Close the dataReader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) Close the connection
                con.Close();
            }

            //returns the list of genres based on movie id
            return genresLst;
        }


        /// <summary>
        /// This method is used to retrieve the movie record from database based on movie id
        /// </summary>
        /// <param name="movieId"></param> It is used to pass the movie id whose movie record is to be retrieved from database
        /// <returns></returns>
        public Movie GetMovieDetailsByMovieId(int movieId)
        {
            Movie movie = new Movie();

            // Retrieving the list of genres from GetGenresByMovieID(movieId) by passing movie id
            movie.Genres = GetGenresByMovieID(movieId);

            // Retrieving the list of actors from GetActorsByMovieID(movieId) by passing movie id
            movie.Actors = GetActorsByMovieID(movieId);

            try
            {
                //2) Configure command
                cmd = new SqlCommand();
                cmd.CommandText = "select movieid,moviename,picture,director,plot,year,boxoffice,released from tbl_movie where movieid = @id";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@id", movieId);

                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read())
                {
                    movie.MovieId = (int)sdr[0];
                    movie.MovieName = sdr[1].ToString();
                    movie.Pic = sdr[2].ToString();
                    movie.Director = sdr[3].ToString();
                    movie.plot = sdr[4].ToString();
                    movie.Year = (int)sdr[5];
                    movie.BoxOffice = sdr[6].ToString();
                    movie.ReleasedDate = (DateTime)sdr[7];
                }
                else
                {
                    throw new Exception("Movie details doesn't exist");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                // Close the connection
                con.Close();
            }

            return movie;
        }


        /// <summary>
        /// This method is used to retrieve the record which contains the list of movies from database based on movie name
        /// </summary>
        /// <param name="movieName"></param> It is used to pass the movie name, inorder to retrieve the record which contains the list of movies from database
        /// <returns></returns>
        public List<Movie> GetMoviesByName(string movieName)
        {
            List<Movie> movieLst = new List<Movie>();
            Movie movies = null;

            try
            {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "select movieid,moviename,picture,year from tbl_movie where moviename like @name";
                cmd.Parameters.Clear();
                cmd.Parameters.AddWithValue("@name", "%" + movieName + "%");

                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command

                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    movies = new Movie
                    {
                        MovieId = (int)sdr[0],
                        MovieName = sdr[1].ToString(),
                        Pic = sdr[2].ToString(),
                        Year = (int)sdr[3]
                    };
                    movieLst.Add(movies);
                }
                //close the datareader
                sdr.Close();
            }
            catch(SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) close the connection
                con.Close();
            }

            //returns the list of movies based on movie name
            return movieLst;
        }


        /// <summary>
        /// This method is used to retrieve the user/owner record from database
        /// </summary>
        /// <returns></returns>
        public UserDetail GetUserDetails()
        {
            UserDetail user = null;

            try
            {
                //2) Configure Command
                cmd = new SqlCommand();
                cmd.CommandText = "select username,picture,city,state from usersdetails";
                cmd.CommandType = System.Data.CommandType.Text;

                //3) Attach connection with command
                cmd.Connection = con;

                //4) Open the connection
                con.Open();

                //5) Execute the command

                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.Read()) //returns bool value
                {
                    user = new UserDetail
                    {
                        UserName = sdr[0].ToString(),
                        Pic = sdr[1].ToString(),
                        City = sdr[2].ToString(),
                        State = sdr[3].ToString()
                    };
                }
                //Close the dataReader
                sdr.Close();
            }
            catch (SqlException ex)
            {
                throw new OMBException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new OMBException(ex.Message);
            }
            finally
            {
                //6) close the connection
                con.Close();
            }

            //returns the record of user detail
            return user;
        }


        /// <summary>
        /// This method is used to update a movie in database based on movie id
        /// </summary>
        /// <param name="movie"></param> It is used to pass an updated movie details to database based on movie id
        public void UpdateMovieByMovieId(Movie movie)
        {
            //2) Configure command
            cmd = new SqlCommand();

            cmd.CommandText = "update tbl_movie set moviename=@mn,picture=@pic,director=@dir,plot=@plot,year=@yr,boxoffice=@box,released=@rel where movieid = @movieId";
            cmd.Parameters.Clear();

            cmd.Parameters.AddWithValue("@movieId", movie.MovieId);
            cmd.Parameters.AddWithValue("@mn", movie.MovieName);
            cmd.Parameters.AddWithValue("@pic", movie.Pic);
            cmd.Parameters.AddWithValue("@dir", movie.Director);
            cmd.Parameters.AddWithValue("@plot", movie.plot);
            cmd.Parameters.AddWithValue("@yr", movie.Year);
            cmd.Parameters.AddWithValue("@box", movie.BoxOffice);
            cmd.Parameters.AddWithValue("@rel", movie.ReleasedDate);

            cmd.CommandType = System.Data.CommandType.Text;

            //3) Attach command with connection
            cmd.Connection = con;

            //4) open the connection
            con.Open();

            //5) Execute the command
            int rowsAffected = cmd.ExecuteNonQuery();

            //6) Close the connection
            con.Close();

            // Calling DeleteMovieGenresByMovieId(movie) method
            DeleteMovieGenresByMovieId(movie);

            if (rowsAffected == 0)
            {
                throw new Exception("Could not update movie details");
            }

        }


        /// <summary>
        /// This method is used to delete the genre/s in database based on movie id and also calling the DeleteMovieActorsByMovieId(movie) method
        /// </summary>
        /// <param name="movie"></param> It is used to pass a movie which contains movie id so that deletion will occur
        public void DeleteMovieGenresByMovieId(Movie movie)
        {
            //2) Configure the command
            cmd = new SqlCommand();

            cmd.CommandText = "delete from tbl_moviegenre where movieid = @id";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@id", movie.MovieId);

            cmd.CommandType = System.Data.CommandType.Text;

            //3) Attach command with connection
            cmd.Connection = con;

            //4) open the connection
            con.Open();

            //5) Execute the command
            int recordsAffected = cmd.ExecuteNonQuery();

            //6) Close the connection
            con.Close();

            // Calling DeleteMovieActorsByMovieId(movie) by passing movie object
            DeleteMovieActorsByMovieId(movie);

            if (recordsAffected == 0)
            {
                throw new Exception("Movie details could not delete");
            }
        }


        /// <summary>
        /// This method is used to delete the actor/s in database based on movie id and also calling the AddActorIdMovieId(movie, movie.MovieId) method
        /// </summary>
        /// <param name="movie"></param> It is used to pass a movie which contains movie id so that deletion will occur
        public void DeleteMovieActorsByMovieId(Movie movie)
        {
            //2) Configure the command
            cmd = new SqlCommand();

            cmd.CommandText = "delete from tbl_movieactor where movieid = @id";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@id", movie.MovieId);

            cmd.CommandType = System.Data.CommandType.Text;

            //3) Attach command with connection
            cmd.Connection = con;

            //4) open the connection
            con.Open();

            //5) Execute the command
            int recordsAffected = cmd.ExecuteNonQuery();

            //6) Close the connection
            con.Close();

            // calling DeleteMovieActorsByMovieId(movie) method by passing movie object and movie id
            AddActorIdMovieId(movie);

            if (recordsAffected == 0)
            {
                throw new Exception("Movie actors could not delete");
            }
        }
    }
}
