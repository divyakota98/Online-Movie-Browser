﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;

using System.Web.Http;

using OMBBusinessLayerLib;
using OMBEntitiesLib;

namespace MovieBrowserWebAPI.Controllers
{
    public class MovieBrowserApiController : ApiController
    {

        /// <summary>
        /// This method is used to retrieve a record of user from business layer
        /// </summary>
        /// <returns></returns>

        [Route("api/MovieBrowserApi/GetUserDetails")]
        public HttpResponseMessage GetUserDetails()
        {
            HttpResponseMessage msgRes = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                var user = bbl.GetUserDetails();

                msgRes = Request.CreateResponse<UserDetail>(HttpStatusCode.OK, user);
            }
            catch (Exception ex)
            {
                msgRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return msgRes;
        }


        /// <summary>
        /// This method is used to retrieve the list of movies from business layer based on movie name
        /// </summary>
        /// <param name="MovieName"></param> It is used to pass the movie name inorder to retrieve the list of movies from business layer
        /// <returns></returns>

        [Route("api/MovieBrowserApi/GetMoviesByName/{MovieName}")]
        public HttpResponseMessage GetMoviesByName(string MovieName)
        {
            HttpResponseMessage msgRes = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                var moviesLst = bbl.GetMoviesByName(MovieName);

                msgRes = Request.CreateResponse<List<Movie>>(HttpStatusCode.OK, moviesLst);
            }
            catch (Exception ex)
            {
                msgRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return msgRes;
        }


        /// <summary>
        /// This method is used to retrieve the record of movie from business layer based on movie id 
        /// </summary>
        /// <param name="id"></param> It is used to pass the movie id inorder to retrieve movie record from business layer
        /// <returns></returns>
        public HttpResponseMessage Get(int id)
        {
            HttpResponseMessage msgRes = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                var movie = bbl.GetMovieDetailsByMovieId(id);

                msgRes = Request.CreateResponse<Movie>(HttpStatusCode.OK, movie);
            }
            catch (Exception ex)
            {
                msgRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            return msgRes;
        }


        /// <summary>
        /// This method is used to retrieve the list of movies from business layer
        /// </summary>
        /// <returns></returns>

        [Route("api/MovieBrowserApi/GetAllMovies")]
        public HttpResponseMessage GetAllMovies()
        {
            HttpResponseMessage msgRes = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                var movieLst = bbl.GetAllMovies();

                msgRes = Request.CreateResponse<List<Movie>>(HttpStatusCode.OK, movieLst);
            }
            catch (Exception ex)
            {
                msgRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return msgRes;
        }


        /// <summary>
        /// This method is used to delete a movie based on movie id
        /// </summary>
        /// <param name="id"></param> It is used to pass movie id to business layer for deletion of movie record

        [Route("api/MovieBrowserApi/DeleteMovieByMovieId/{id}")]
        public HttpResponseMessage DeleteMovieByMovieId(int id)
        {
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Movie details deleted successfully");

            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                bbl.DeleteMovieByMovieId(id);
            }
            catch (Exception ex)
            {
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return errRes;
        }
    


        /// <summary>
        /// This method is used to post the movie detail to business layer
        /// </summary>
        /// <param name="movie"></param> It is used to pass the movie object to business layer
        /// <returns></returns>
        public HttpResponseMessage Post([FromBody]Movie movie)
        {
            HttpResponseMessage err = Request.CreateResponse(HttpStatusCode.OK, "Movie added successfully");
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                bbl.AddMovieDetails(movie);
            }
            catch(Exception ex)
            {
                err = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            return err;
        }


        /// <summary>
        /// This method is used to retrieve the list of genres and actors through movie object
        /// </summary>
        /// <returns></returns>
        
        [Route("api/MovieBrowserApi/GetAllActorsGenres")]
        public HttpResponseMessage GetAllActorsGenres()
        {
            HttpResponseMessage msgRes = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                var actorsLst = bbl.GetAllActors();
                var genresLst = bbl.GetAllGenres();

                var movie = new Movie
                {
                    Actors = actorsLst,
                    Genres = genresLst,
                };

                msgRes = Request.CreateResponse<Movie>(HttpStatusCode.OK, movie);
            }
            catch(Exception ex)
            {
                msgRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            return msgRes;
        }


        /// <summary>
        /// This method is used to add new user/admin credentials to bussiness layer 
        /// </summary>
        /// <param name="user"></param> It is used to pass user credentials like UserName, password and confirmPassword to business layer
        /// <returns></returns>
        
        [Route("api/MovieBrowserApi/AddUserRegistrationDetails")]
        public HttpResponseMessage AddUserRegistrationDetails(UserRegistration user)
        {
            HttpResponseMessage err = Request.CreateResponse(HttpStatusCode.OK, "New admin details added successfully");
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                bbl.AddUserRegistrationDetails(user);
            }
            catch (Exception ex)
            {
                err = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            return err;
        }


        /// <summary>
        /// This method retrieve the admin record from business layer based on admin name
        /// </summary>
        /// <param name="name"></param> It is used to pass the admin name whose record contains admin name is to be retrieved from business layer
        /// <returns></returns>
        
        [Route("api/MovieBrowserApi/GetUserNameByName/{name}")]
        public HttpResponseMessage GetUserNameByName(string name)
        {
            HttpResponseMessage errMsg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                var userName = bbl.GetUserNameByName(name);

                errMsg = Request.CreateResponse<LoginDetail>(HttpStatusCode.OK, userName);
            }
            catch(Exception ex)
            {
                errMsg = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }
            return errMsg;
        }


        /// <summary>
        /// This method retrieve the admin record from business layer based on admin name
        /// </summary>
        /// <param name="name"></param> It is used to pass the admin name whose record contains admin password is to be retrieved from business layer
        /// <returns></returns>
        
        [Route("api/MovieBrowserApi/GetUserPwdByName/{name}")]
        public HttpResponseMessage GetUserPwdByName(string name)
        {
            HttpResponseMessage errMsg = Request.CreateResponse(HttpStatusCode.OK);
            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                var pwd = bbl.GetUserPwdByName(name);

                errMsg = Request.CreateResponse<LoginDetail>(HttpStatusCode.OK, pwd);
            }
            catch(Exception ex)
            {
                errMsg = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return errMsg;
        }


        /// <summary>
        /// This method is used to update the movie detail based on movie id and passing to business layer
        /// </summary>
        /// <param name="movie"></param> It is used to pass an updated movie object
        /// <param name="id"></param> It is used to pass an movie id for updation of movie record
        /// <returns></returns>
        public HttpResponseMessage Put([FromBody]Movie movie, int id)
        {
            HttpResponseMessage errRes = Request.CreateErrorResponse(HttpStatusCode.OK, "Movie details updated");

            try
            {
                OMBBusinessLayer bbl = new OMBBusinessLayer();
                bbl.UpdateMovieByMovieId(movie);
            }
            catch (Exception ex)
            {
                errRes = Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex.Message);
            }

            return errRes;
        }
    }
}
