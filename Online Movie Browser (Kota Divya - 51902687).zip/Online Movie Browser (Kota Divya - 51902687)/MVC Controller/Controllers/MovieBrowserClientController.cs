﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Net.Http;
using Newtonsoft.Json;
using OnlineMovieBrowser.Models;

namespace OnlineMovieBrowser.Controllers
{
    [Authorize]
    public class MovieBrowserClientController : Controller
    {
        // GET: MovieBrowserClient

        /// <summary>
        /// This action is used to returns an Index view and no authorization requires for user
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        /// <summary>
        /// This action is used to display the list of movies retrieving from web api based on searching of movie name and no authorization to this action
        /// </summary>
        /// <param name="MovieName"></param>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult GetMoviesByName(string MovieName)
        {

            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;

                var result = client.GetStringAsync("MovieBrowserApi/GetMoviesByName/" + MovieName).Result;

                //Get the list of movies by search name like movieName
                var moviesLst = JsonConvert.DeserializeObject<List<Movie>>(result);

                //Returns the movies list to 'GetMoviesByName view' to display
                return View(moviesLst);
            }
        }


        /// <summary>
        /// This action is used to DisplayMovieDetails By movieId and no authorization to this action
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult DisplayMovieDetailsById(int id)
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("MovieBrowserApi/" + id).Result;

                // Get the movie from web api based on movie id 
                var movie = JsonConvert.DeserializeObject<Movie>(result);

                //Returns the movie record to 'DisplayMovieDetailsById view' to display
                return View(movie);
            }
        }


        /// <summary>
        /// This action is used to display all movies and no authorization to this action
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult DisplayAllMovies()
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("MovieBrowserApi/GetAllMovies").Result;

                //Get the all movies in database through web api
                var moviesLst = JsonConvert.DeserializeObject<List<Movie>>(result);

                //Return all movies to 'DisplayAllMovies view' for display
                return View(moviesLst);
            }
        }

        
        /// <summary>
        /// This action is used to delete a movie record in database through web api based on movie id choosen by admin and this action can be accessed by admin/owner but not user
        /// </summary>
        /// <param name="id"></param> It is used to pass movie id to web api inorder to delete a movie record
        /// <returns></returns>
        public ActionResult DeleteMovieByMovieId(int id)
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.DeleteAsync("MovieBrowserApi/DeleteMovieByMovieId/" + id).Result;

                if (TempData["msg"] != null)
                {
                    TempData.Remove("msg");
                }
                if (result.IsSuccessStatusCode == true)
                {
                    TempData.Add("msg1", "Movie details deleted successfully");
                }
                else
                {
                    TempData.Add("msg2", "Could not delete Movie details");
                }

                //Return to 'DisplayAllMovies view' inorder to print respective message based on deletion operation
                return RedirectToAction("DisplayAllMovies");
            }
        }


        /// <summary>
        /// This action is used to display user/owner details and retreving from web api and no authorization to this action
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        public ActionResult DisplayUserDetails()
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("MovieBrowserApi/GetUserDetails").Result;

                //Get the user/owner record from web api
                var user = JsonConvert.DeserializeObject<UserDetail>(result);

                //Return the user record to 'DisplayUserDetails view' to display
                return View(user);
            }
        }


       
        /// <summary>
        /// This action is used to return the 'AddMovieDetails view' to create a form for posting movie details by only admin/owner
        /// </summary>
        /// <returns></returns>
        public ActionResult AddMovieDetails()
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("MovieBrowserApi/GetAllActorsGenres").Result;

                var movie = JsonConvert.DeserializeObject<Movie>(result);

                var moviesVm = new MovieVM
                {
                    Actors = new MultiSelectList(movie.Actors, "ActorId","ActorName"),
                    Genres = new MultiSelectList(movie.Genres, "GenreId","GenreName")
                };

                //
                return View(moviesVm);
            }
        }


        
        /// <summary>
        /// This method is used to retrieving the MovieVM object inorder to post the movie detail in database via web api
        /// </summary>
        /// <param name="movievm"></param> It is used to pass to web api for posting movie detail to web api
        /// <returns></returns>
        [HttpPost]
        public ActionResult AddMovieDetails(MovieVM movievm)
        {
            
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                var movie = new Movie()
                {
                    MovieId = movievm.MovieId,
                    MovieName = movievm.MovieName,
                    Pic = movievm.Pic,
                    Director = movievm.Director,
                    plot = movievm.plot,
                    Year = movievm.Year,

                    Genres = movievm.SelectedGenres.Select(o => new Genre { GenreId = Convert.ToInt32(o) }).ToList(),
                    Actors = movievm.SelectedActors.Select(o => new Actor { ActorId = Convert.ToInt32(o) }).ToList(),

                    BoxOffice = movievm.BoxOffice,
                    ReleasedDate = movievm.ReleasedDate
                };
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync("MovieBrowserApi", movie).Result;

                if (result.IsSuccessStatusCode == true)
                {
                    TempData.Add("msg1", "Movie details added successfully");
                }
                else
                {
                    TempData.Add("msg2", "Could not add movie details");
                }

                //Return to 'AddMovieDetails view' to print respective messages based on posting operation 
                return RedirectToAction("AddMovieDetails");
            }
        }


        /// <summary>
        /// This action is used to return the 'Edit view' to display a form contains movie details for updating by only admin/owner 
        /// </summary>
        /// <param name="id"></param> It is used to pass the movie id inorder to upadate movie detail 
        /// <returns></returns>
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.GetStringAsync("MovieBrowserApi/" + id).Result;
                var result1 = client.GetStringAsync("MovieBrowserApi/GetAllActorsGenres").Result;

                var movie1 = JsonConvert.DeserializeObject<Movie>(result);
                var movie2 = JsonConvert.DeserializeObject<Movie>(result1);


                var movieVm = new MovieVM
                {
                    MovieId = movie1.MovieId,
                    MovieName = movie1.MovieName,
                    Pic = movie1.Pic,
                    Director = movie1.Director,
                    plot = movie1.plot,
                    Year = movie1.Year,

                    Actors = new MultiSelectList(movie2.Actors, "ActorId", "ActorName"),
                    Genres = new MultiSelectList(movie2.Genres, "GenreId", "GenreName"),

                    //SelectedGenres = movie.Genres.Select(o => o.GenreId.ToString()).ToList(),
                    //SelectedActors = movie.Actors.Select(o => o.ActorId.ToString()).ToList(),

                    BoxOffice = movie1.BoxOffice,
                    ReleasedDate = movie1.ReleasedDate
                };

                return View(movieVm);
            }
        }
        

        /// <summary>
        /// This action is used to post the updated movie detail in database via web api
        /// </summary>
        /// <param name="movievm"></param> It is used to pass updated movievm to web api
        /// <returns></returns>
        [HttpPost]
        public ActionResult Edit(MovieVM movievm)
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                var movie = new Movie()
                {
                    MovieId = movievm.MovieId,
                    MovieName = movievm.MovieName,
                    Pic = movievm.Pic,
                    Director = movievm.Director,
                    plot = movievm.plot,
                    Year = movievm.Year,

                    Genres = movievm.SelectedGenres.Select(o => new Genre { GenreId = Convert.ToInt32(o) }).ToList(),
                    Actors = movievm.SelectedActors.Select(o => new Actor { ActorId = Convert.ToInt32(o) }).ToList(),

                    BoxOffice = movievm.BoxOffice,
                    ReleasedDate = movievm.ReleasedDate
                };

                client.BaseAddress = uri; 
                var result = client.PutAsJsonAsync("MovieBrowserApi/" + movie.MovieId, movie).Result;

                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg1", "Movie details updated successfully");
                }
                else
                {
                    ViewData.Add("msg2", "Could not update movie details");
                }

                //Return to 'Edit view' inorder to print respective messages based on updating operation
                return RedirectToAction("Edit");
            }
        }
    }
}