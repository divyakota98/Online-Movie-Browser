﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Newtonsoft.Json;
using OnlineMovieBrowser.Models;

namespace OnlineMovieBrowser.Controllers
{
    public class SecurityController : Controller
    {
        // GET: Security
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// This action is used to return 'Login view' which displays login page
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Login()
        {
            var returnUrl = Request.QueryString.Get("ReturnUrl");
            ViewData.Add("returnUrl", returnUrl);
            return View();
        }


        /// <summary>
        /// This action is used to validate the admin credentials 
        /// </summary>
        /// <param name="login"></param> It is used to pass the admin credentials to database via web api for validation
        /// <returns></returns>
        [HttpPost]
        public ActionResult Login(LoginDetail login)
        {
           
                Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                try
                {

                    var result1 = client.GetStringAsync("MovieBrowserApi/GetUserNameByName/" + login.Name).Result;
                    var name = JsonConvert.DeserializeObject<LoginDetail>(result1);
                    string userName = name.Name;


                    var result2 = client.GetStringAsync("MovieBrowserApi/GetUserPwdByName/" + login.Name).Result;
                    var password = JsonConvert.DeserializeObject<LoginDetail>(result2);
                    string userPassword = password.Pwd;


                    if ((login.Name.Equals(userName)) && (login.Pwd.Equals(userPassword)))
                    {
                        FormsAuthentication.SetAuthCookie(login.Name, false);
                        var returnUrl = Request.Form["returnUrl"];

                        return Redirect(returnUrl);
                    }
                    else
                    {
                        ViewData.Add("errMsg", "UserName and Password are invalid, Please try again.");
                    }

                    var returnUrl2 = Request.QueryString.Get("ReturnUrl");
                    ViewData.Add("returnUrl", returnUrl2);

                    return View();
                }
                catch (Exception ex)
                {
                    ViewData.Add("errMsg1", "Looking like you donot have an account, Please register.");
                    return View();
                }
            }
        }

   
        /// <summary>
        /// This action is used to return 'Register view' to display registration form to new user
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        
        /// <summary>
        /// This action is used to collect and add the new user credentials to database via web api
        /// </summary>
        /// <param name="register"></param> It is used to pass register credentials inorder to -
        /// - insert into database via web api
        /// <returns></returns>
        [HttpPost]
        public ActionResult Register(UserRegistration register)
        {
            Uri uri = new Uri("http://localhost:62711/api/");

            using (var client = new HttpClient())
            {
                client.BaseAddress = uri;
                var result = client.PostAsJsonAsync("MovieBrowserApi/AddUserRegistrationDetails", register).Result;

                if (result.IsSuccessStatusCode == true)
                {
                    ViewData.Add("msg", "Your Registration is Successful");
                }
                else
                {
                    ViewData.Add("errMsg", "Could not insert credentials into database, please register again");
                }

                return View();
            }
        }


        /// <summary>
        /// This action is used to logout after login
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return View("Logout");
        }
    }
}