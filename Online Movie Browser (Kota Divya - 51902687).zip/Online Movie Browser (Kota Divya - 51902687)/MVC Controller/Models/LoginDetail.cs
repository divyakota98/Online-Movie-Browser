﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

using CustomValidationsLib;

namespace OnlineMovieBrowser.Models
{
    public class LoginDetail
    {
        [Required(ErrorMessage = "User name field must not be empty")]
        [StringLength(20, MinimumLength = 3, ErrorMessage = "User name must be between 3 to 20 characters")]

        //Custom validation for checking whether the user name is in between 3 to 20 characters or not
        [CustomUserName(ErrorMessage = "User name must be between 3 to 20 characters")]
        public string Name { get; set; }


        [Required(ErrorMessage = "Password field must not be empty")]
        public string Pwd { get; set; }
    }
}