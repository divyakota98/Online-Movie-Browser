﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

using CustomValidationsLib;

namespace OnlineMovieBrowser.Models
{
    public class UserRegistration
    {

        [Required(ErrorMessage = "User name field must not be empty")]
        [StringLength(10, MinimumLength = 3, ErrorMessage = "User name must be between 3 to 20 characters")]
       
        //Custom validation for checking user name is empty or not
        [CustomUserName(ErrorMessage = "User name must be between 3 to 20 characters")]
        public string UserName { get; set; }



        [Required(ErrorMessage = "Password field must not be empty")]
        [StringLength(8, MinimumLength = 5, ErrorMessage = "Password must be between 5 to 8 characters")]

       
        // Custom Validation for checking user password is in between 5 to 8 characters or not
        [CustomRegistrationPasswordValidation(ErrorMessage = "Password must be between 5 to 8 characters")]
        public string Password { get; set; }



        [Required(ErrorMessage = "Confirm Password field must not be empty")]
        [Display(Name = "Confirm Password")]
        [Compare(nameof(Password), ErrorMessage = "Passwords does not match")]
        public string ConfirmPwd { get; set; }
    }
}

