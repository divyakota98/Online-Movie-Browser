﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using System.Web.Mvc;

namespace OnlineMovieBrowser.Models
{
    public class MovieVM
    {
        [Required]
        public int MovieId { get; set; }

        [Required]
        public string MovieName { get; set; }

        [Required]
        public string Pic { get; set; }

        [Required]
        public string Director { get; set; }

        [Required]
        public string plot { get; set; }

        [Required]
        public int Year { get; set; }

        //public List<Genre> Genres { get; set; }
        //public List<Actor> Actors { get; set; }

        public MultiSelectList Genres { get; set; }
        public List<string> SelectedGenres { get; set; }

        public MultiSelectList Actors { get; set; }
        public List<string> SelectedActors { get; set; }

        [Required]
        public string BoxOffice { get; set; }

        [Required]
        [DataType(DataType.Date)]
        public DateTime ReleasedDate { get; set; }
    }
}