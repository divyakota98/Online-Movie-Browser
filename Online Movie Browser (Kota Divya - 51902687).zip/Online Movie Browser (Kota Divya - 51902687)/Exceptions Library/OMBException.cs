﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OMBExceptionLib
{
    public class OMBException : Exception
    {
        public OMBException(string errMsg) : base(errMsg)
        {
            //ToDo log the error in file or elsewhere
            Console.WriteLine(errMsg);
        }
    }
}
